﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Cay.Controllers
{
    public class NBController : Controller
    {
        // GET: NB
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult NB01() {
            return View();
        }
        public ActionResult NB02()
        {
            return View();
        }
        public ActionResult NB03()
        {
            return View();
        }
        public ActionResult NB04()
        {
            return View();
        }
        public ActionResult NB05()
        {
            return View();
        }
        public ActionResult airplane()
        {
            return View();
        }
        public ActionResult fish()
        {
            return View();
        }
    }
}