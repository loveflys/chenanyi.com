﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Cay.Controllers
{
    public class MoBanController : Controller
    {
        // GET: MoBan
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Ceshi()
        {
            return View();
        }
    }
}