﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Cay.Controllers
{
    public class JiaziController : Controller
    {
        // GET: Jiazi
        public ActionResult Index()
        {
            return View();
        }
    }
}