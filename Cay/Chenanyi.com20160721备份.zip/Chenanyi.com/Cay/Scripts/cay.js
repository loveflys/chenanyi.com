﻿///
/*
 *  Jquery模仿学习之路
 *  author：陈安一
 *  Data：2015-09-01 14:58
 */
(function () {
    //cay变量定义  
    var cay = function () {

    }
    //将定义的cay定义为全局变量  
    window.cay = cay;
})